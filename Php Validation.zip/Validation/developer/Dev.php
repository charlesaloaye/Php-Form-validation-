
<?php
include"info.php";
?>