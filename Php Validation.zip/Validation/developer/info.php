
<?php
include"Header.php";
?>
 <?php
echo'
<div class="container">
 <div class="btn btn-success btn-block">
 <h3 align="center">About Me</h3></div>
 <br>
<center><img src="developer.jpg" alt="Sedenu Aloaye Charles@developer" class="img-rounded" height="400" width="300">
</center>
Charles Aloaye , is a well known web Developer in Etsako East Edo State Agenebode where he hails from and in Africa based on the assistance he do render to upcoming web developers,software designers.
He is currently one of the top moderator at a facebook group own by Asia Continent. C++,web and programmers
and another one own by his team NAIJA coders lab as the admin.
He Obtained his SSCE result at Success Secondary School Agenebode,one of outstanding high school in Etsako east axis.
he his currently looking forward to be admitted by one of Nigeria  Tertially Institution every Nigerian will dream of going.
you can follow him on some of his social media official account
<p>
<span class="fa fa-instagram"></span> &nbsp; as <a href="http://Instagram.com/Sedenu Charles">Sedenu charles </a><br>
<span class="fa fa-facebook"></span> &nbsp; as <a href="http://facebook.com/Sedenu.charles">Sedenucharles</a> also on <br>
<span class="fa fa-twitter"></span> &nbsp; as <a href="http://twitter.com/sedenucharles">@sedenucharles</a></p>
</div>';
?>