<!DOCTYPE html>
<html lang="en"><head>
	<meta charset="UTF-8">		
<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<title>php email,password and confirm password validtion for your Project</title>
		<meta name="description" content="Php validation">
		<meta name="keywords" content="php,password validation,email validation using php">
		<meta name="author" content="Sedenu.A.Charles">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
			
			</head>