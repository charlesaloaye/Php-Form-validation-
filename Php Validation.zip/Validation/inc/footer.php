	 <div class="panel panel-footer" style="margin:45px;">
	<div class="btn btn-default btn-block">
<footer> Design by <font color="red">&hearts;</font> <a href="developer/dev.php">Sedenu Aloaye Charles</a> &copy; 2017</footer>
   </div>
   </div>
		 </body>
		 </html>