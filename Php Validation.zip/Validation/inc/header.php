<!DOCTYPE html>
<html lang="en">
     <head>
       <meta Charset="UTF-8">
       <meta http-equiv="X-UA-Compatible" content="IE=edge">
       <meta name="viewport" content="width=device-width, initial-scale=1">
<title>Form Validation</title>
		   <meta name="description" content="Php Form Validation by Sedenu Charles">
		   <meta name="keywords" content="Signup form,Html5 form validation with php,bootstrap form with php">
		   <meta name="author" content="Sedenu.A.Charles">
   <!-- Bootstrap 4 core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font/css/font-awesome.min.css" type="text/css" rel="stylesheet">
<link href="css/style.css" type="text/css" rel="stylesheet">
      </head>
			