              
<!--calling header-->
		<?php
		 include"inc/header.php";
		 ?>
	<?php
	include"inc/body.php";
	?>
		<!--calling footer -->

	 		<?php
	 		 include "inc/footer.php";
	 		?>
	 	

			