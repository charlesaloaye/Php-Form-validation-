             
<!--calling header-->
		<?php include"inc/header.php"?>
		<?php
		include"inc/signin.php";
		?>
		<!--calling footer -->

			<?php 
			include"inc/footer.php";
			?>
			